### Features NOME da LIB + Versão
- Função 01
- Função 02
- Etc ...

```sh
// Como utilizar a lib
// Ex lib com construtor
NewLib new = NewLib();
new.chamaFuncao();

// Ex lib sem construtor
NewLib.chamafuncao();
```

##### Seu nome para os créditos
##### Contato caso queira deixar, email, redes sociais, etc