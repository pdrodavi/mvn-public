/**
 * Nome da classe principal pode mudar a sua escolha
 * Você pode criar outras classes e pacotes
**/

public class ExampleBuildLib {

    /**
     * Para gerar o JAR:
     * mvn clean
     * mvn compile
     * mvn package
     * Seu arquivo .jar estará no diretório target com nomeDoArtifactDefinido-versao.jar
     */

    /**
     Import em outro projeto
     double op1 = ExampleBuildLib.calculoPorcentagem(100, 50, 1);
     double op2 = ExampleBuildLib.calculoPorcentagem(100, 50, 2);

     saída
     System.out.println(op1);
     System.out.println(op2);
     **/

    /**
     * Declarar as funções que deseja que sua Lib forneça
     * Deixar como public as principais e as secundárias como private
     * Exemplo
     */

    public static double calculoPorcentagem(double valorInicial, double porcentagem, int operacao) {
        if (operacao == 1) {
            return aumentar(valorInicial, porcentagem);
        } else if (operacao == 2) {
            return diminuir(valorInicial, porcentagem);
        } else {
            return 0;
        }
    }

    protected static double aumentar(double valorInicial, double porcentagem) {
        double valorPercentual = (porcentagem / 100) * valorInicial;
        return valorInicial + valorPercentual;
    }

    protected static double diminuir(double valorInicial, double porcentagem) {
        double valorPercentual = (porcentagem / 100) * valorInicial;
        return valorInicial - valorPercentual;
    }

}
